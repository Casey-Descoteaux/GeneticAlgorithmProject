#include "pch.h"
#include "Child.h"
#include<vector>
#include<algorithm>
#include <iostream>
#include<stdio.h>

using std::vector;
using std::array;
using std::string;
using std::cout;
using std::unique;
using std::sort;
using std::distance;
using std::find;


// Initialization methods

// Create the initial variable pool determined by users
void Child::InitializeVarPool(int numberOfVariables)
{
	string validOperations[2] = { "PLUS", "MINUS" };
	Poly newPoly;
	int charCode = 65;
	int alphLoops = 0;
	string varName;
	for (int i = 0; i < numberOfVariables; i++)
	{
		if (charCode == 91)
		{
			alphLoops += 1;
			charCode = 65;
		}

		if (alphLoops > 0 && alphLoops < 28)
		{
			varName = (char)(65 + (alphLoops - 1));
			varName += (char)charCode;
		}
		else if (alphLoops == 0)
		{
			varName = (char)charCode;
		}

		float min = -10.00;
		float max = 10.00;

		newPoly.SetVar(varName);
		newPoly.SetBaseVal(min + static_cast<float> (rand() / (static_cast<float>(RAND_MAX / (max - min)))));
		newPoly.SetPower(rand() % 11);
		newPoly.SetOperation(validOperations[rand() % 2]);
		newPoly.SetResult();
		varPool.push_back(newPoly);

		charCode += 1;
	}
}

// Each Child sets their own inital values for the variables
void Child::SetVarPool(vector<Poly> vars)
{
	vector<Poly> temp = vars;

	float min = -10.00;
	float max = 10.00;
	vector<Poly>::iterator itr;
	for (itr = temp.begin(); itr != temp.end(); ++itr)
	{
		itr->SetBaseVal(min + static_cast<float> (rand() / (static_cast<float>(RAND_MAX / (max - min)))));
		itr->SetResult();
		usedVars.push_back(*itr);
	}
}

// The equation is created and any variables used are put into usedVars
void Child::CreateInitialState(int numberOfPolys, int numberOfVars)
{
	vector<Poly>::iterator itr;
	vector <Poly>::iterator usedVarItr;
	bool addToUsed;

	for (int i = 0; i < (numberOfPolys - 1); i++)
	{
		addToUsed = true;

		itr = varPool.begin();
		for (int x = rand() % (numberOfVars - 1); x != 0; x--)
		{
			++itr;
		}

		currentState.push_back(*itr);

		for (usedVarItr = usedVars.begin(); usedVarItr != usedVars.end(); ++usedVarItr)
		{
			if (itr->GetVar() == usedVarItr->GetVar())
			{
				addToUsed = false;
			}
		}

		if (addToUsed)
		{
			usedVars.push_back(*itr);
		}
	}
}

// Initializes the target based on user input
void Child::SetTarget(float value)
{
	target = value;
}

// Sets the equation for all Child objects in initialization
void Child::SetCurrentState(vector<Poly> values)
{
	currentState = values;
}


// Set methods

// Sets the values of the crossover variables
void Child::CrossoverVars(int crossoverPoint, vector<Poly> p2vars)
{
	vector<Poly>::iterator itr = usedVars.begin();
	vector<Poly>::iterator crossItr = p2vars.begin();
	for (int i = 0; i != crossoverPoint; i++)
	{
		++itr;
	}

	for (int i = crossoverPoint; i != usedVars.size(); ++i)
	{
		itr->SetBaseVal(crossItr->GetBaseVal());
		itr->SetResult();
		++itr;
		++crossItr;
	}
}

// Alters the variable values in currentState after crossover and mutation
void Child::AdjustCurrentStateVals()
{
	vector<Poly> temp;
	vector<Poly>::iterator itr;
	for (itr = currentState.begin(); itr != currentState.end(); ++itr)
	{
		vector<Poly>::iterator i;
		for (i = usedVars.begin(); i != usedVars.end(); ++i)
		{
			if (itr->GetVar() == i->GetVar())
			{
				temp.push_back(*i);
			}
		}
	}

	currentState = temp;
}

// Solves the equation and compares the outcome to the target given by the user
void Child::EvaluateFitness()
{
	runningTotal = 0;
	vector<Poly>::iterator itr;
	for (itr = currentState.begin(); itr != currentState.end(); ++itr)
	{
		if (itr->GetOperation() == "PLUS")
		{
			runningTotal += itr->GetResult();
		}
		else if (itr->GetOperation() == "MINUS")
		{
			runningTotal -= itr->GetResult();
		}
	}

	fitness = target - runningTotal;
}

// Mutates the base value of a random variable per iteration
void Child::MutateVar(int mutationNum)
{
	float min = -10.00;
	float max = 10.00;
	for (int i = mutationNum; i != 0; i--)
	{
		int randIndex = rand() % usedVars.size();
		usedVars[randIndex].SetBaseVal(min + static_cast<float> (rand() / (static_cast<float>(RAND_MAX / (max - min)))));
		usedVars[randIndex].SetResult();
	}

	AdjustCurrentStateVals();
	EvaluateFitness();
}


// Get methods
vector<Poly> Child::GetCurrentState()
{
	return currentState;
}

float Child::GetFitness()
{
	return fitness;
}

float Child::GetTarget()
{
	return target;
}

vector<Poly> Child::GetVarPool()
{
	return varPool;
}

vector<Poly> Child::GetUsedVars()
{
	return usedVars;
}

void Child::PrintState()
{
	vector<Poly>::iterator itr;

	for (itr = currentState.begin(); itr != currentState.end(); ++itr)
	{
		cout << itr->GetBaseVal() << " ^ " << itr->GetPower() << " " << itr->GetOperation() << " ";
	}
	cout << "\n";
}

Child::Child()
{
}


Child::~Child()
{
}
