#pragma once

#include <string>

using std::string;

class Poly
{
public:
	// Get methods
	string GetVar();
	float GetBaseVal();
	int GetPower();
	string GetOperation();
	float GetResult();

	// Set methods
	void SetVar(string);
	void SetBaseVal(float);
	void SetPower(int);
	void SetOperation(string);
	void SetResult();

	Poly();
	~Poly();

private:
	// Variables
	string var;
	string operation;
	float base;
	int power;
	float result;
};

