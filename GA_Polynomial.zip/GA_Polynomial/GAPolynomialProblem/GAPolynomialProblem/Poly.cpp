#include "pch.h"
#include "Poly.h"
#include <string>
#include <iostream>
#include<math.h>

using std::string;

// Get methods
string Poly::GetVar()
{
	return var;
}
float Poly::GetBaseVal()
{
	return base;
}
int Poly::GetPower()
{
	return power;
}
string Poly::GetOperation()
{
	return operation;
}
float Poly::GetResult()
{
	return result;
}


// Set methods
void Poly::SetVar(string value)
{
	var = value;
}
void Poly::SetBaseVal(float value)
{
	base = value;
}
void Poly::SetPower(int value)
{
	power = value;
}
void Poly::SetOperation(string value)
{
	operation = value;
}
void Poly::SetResult()
{
	result = pow(base, power);
}

Poly::Poly()
{
}

Poly::~Poly()
{
}
