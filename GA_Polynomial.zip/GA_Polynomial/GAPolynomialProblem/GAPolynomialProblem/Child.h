#pragma once
#include"Poly.h"
#include<vector>

using std::vector;

class Child
{
public:
	// Initialization methods
	void SetCurrentState(vector<Poly>);
	void SetVarPool(vector<Poly>);
	void EvaluateFitness();
	void SetTarget(float);

	// Set methods
	void CrossoverVars(int crossoverPoint, vector<Poly>);
	void InitializeVarPool(int);
	void AdjustCurrentStateVals();
	void MutateVar(int);

	// Get methods
	vector<Poly> GetCurrentState();
	void CreateInitialState(int, int);
	float GetFitness();
	float GetTarget();
	vector<Poly> GetVarPool();
	vector<Poly> GetUsedVars();
	void PrintState();

	Child();
	~Child();

private:
	// Variables
	vector<Poly> currentState;
	vector<Poly> varPool;
	vector<Poly> usedVars;
	float fitness;
	float runningTotal = 0;
	float target;
};

