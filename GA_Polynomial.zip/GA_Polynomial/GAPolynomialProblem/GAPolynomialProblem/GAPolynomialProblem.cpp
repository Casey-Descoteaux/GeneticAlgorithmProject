#include "pch.h"
#include <iostream>
#include<fstream>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <vector>
#include "Poly.h"
#include "Child.h"

using std::vector;
using std::string;
using std::array;
using std::cout;
using std::cin;
using std::getline;
using std::ofstream;
using std::endl;
using std::ios;

#define	POPULATION	100

// Biased random selection to determine the index of the parents for crossover
int	BiasedRand(void)
{
	int workingVal;

	workingVal = rand() % (POPULATION * 15);

	if (workingVal < (POPULATION * 8))
	{
		return (workingVal % (POPULATION / 4));
	}
	else if (workingVal < (POPULATION * 12))
	{
		return (workingVal % (POPULATION / 4)) + (POPULATION / 4);
	}
	else if (workingVal < (POPULATION * 14))
	{
		return (workingVal % (POPULATION / 4)) + ((POPULATION / 4) * 2);
	}
	else
	{
		return (workingVal % (POPULATION / 4)) + ((POPULATION / 4) * 3);
	}
}

// Sort the active population by fitness value
void PopulationSort(Child toSort[])
{
	int i;
	int x;
	int minCompare;
	Child temp;

	for (i = 0; i < POPULATION - 1; i++)
	{
		minCompare = i;

		for (x = i + 1; x < POPULATION; x++)
		{
			if (abs(toSort[x].GetFitness()) < abs(toSort[minCompare].GetFitness()))
			{
				minCompare = x;
			}
		}

		temp = toSort[i];
		toSort[i] = toSort[minCompare];
		toSort[minCompare] = temp;
	}
}

// Get the midpoint of usedVars and apply crossover at this point
Child Crossover(Child parentOne, Child parentTwo, int numberOfVars)
{
	Child crossoverChild = parentOne;
	int crossoverPoint = (parentOne.GetUsedVars().size() - 1) / 2;
	vector<Poly> parentTwoExpressions = parentTwo.GetUsedVars();
	vector<Poly>::iterator p2itr = parentTwoExpressions.begin();
	vector<Poly> temp;

	for (int i = 0; i < crossoverPoint; i++)
	{
		++p2itr;
	}

	for (int i = crossoverPoint; i != parentOne.GetUsedVars().size(); ++i)
	{
		temp.push_back(*p2itr);
		++p2itr;
	}

	crossoverChild.CrossoverVars(crossoverPoint, temp);
	crossoverChild.AdjustCurrentStateVals();
	crossoverChild.EvaluateFitness();

	return crossoverChild;
}

// Based on user input for frequency mutate a portion of the variables based on the equation length
void Mutation(string mutation, Child arrayUsed[], int numberOfExpressions)
{
	if (mutation == "Low")
	{
		for (int i = 0; i < POPULATION / 5; i++)
		{
			int randIndex = rand() % POPULATION;
			arrayUsed[randIndex].MutateVar(numberOfExpressions / 3);
		}
	}
	else if (mutation == "Moderate")
	{
		for (int i = 0; i < POPULATION / 4; i++)
		{
			int randIndex = rand() % POPULATION;
			arrayUsed[randIndex].MutateVar(numberOfExpressions / 3);
		}
	}
	else if (mutation == "High")
	{
		for (int i = 0; i < POPULATION / 3; i++)
		{
			int randIndex = rand() % POPULATION;
			arrayUsed[randIndex].MutateVar(numberOfExpressions / 3);
		}
	}
}

int main()
{
	#ifdef DEBUG
		srand(0x696969);				// Initilize the random number generator, fixed seed.
	#else
		srand((unsigned)time(NULL));
	#endif

	// Excel file
	ofstream output;
	output.open("BestFitnessValues.csv", ios::out);

	// Get user inputs to define parameters
	int numberOfExpressions;
	int numberOfVariables;
	float targetValueInput;
	int numberOfGenerations;
	string mutationLevel;
	int generationCount = 1;

	cout << "How many expression should be in the equation? ";
	cin >> numberOfExpressions;
	cout << "What is the maximum number of variables that should be used? ";
	cin >> numberOfVariables;
	cout << "What is the target value? ";
	cin >> targetValueInput;
	cout << "Mutation Level: None, Low, Moderate, High ";
	cin >> mutationLevel;
	cout << "How many generations should there be? ";
	cin >> numberOfGenerations;

	// Alternating population arrays to store consecutive generations
	Child populationOne[POPULATION] = {};
	Child populationTwo[POPULATION] = {};

	// Creates the initial generation
	Child initialState;
	initialState.InitializeVarPool(numberOfVariables);
	initialState.CreateInitialState(numberOfExpressions, numberOfVariables);

	// Creates each Child in the first population
	for (int i = 0; i < POPULATION; i++)
	{
		Child newChild;
		newChild.SetVarPool(initialState.GetUsedVars());
		newChild.SetCurrentState(initialState.GetCurrentState());
		newChild.AdjustCurrentStateVals();
		newChild.SetTarget(targetValueInput);
		newChild.EvaluateFitness();
		populationOne[i] = newChild;
 	}

	PopulationSort(populationOne);

	cout << "\n";

	cout << "Generation " << generationCount << "\n";
	cout << populationOne[0].GetFitness() << "\n";
	generationCount += 1;


	// Looping crossover and mutation and inserting the Child outcomes to either populationOne or populationTwo
	int parentOneIndex;
	int parentTwoIndex;
	Child parentOne;
	Child parentTwo;
	int populationArrayToUse = 2;
	
		while (generationCount <= numberOfGenerations)
		{
			for (int i = 0; i < (POPULATION/2); i++)
			{
				if (populationArrayToUse == 2)
				{
					parentOneIndex = BiasedRand();
					parentOne = populationOne[parentOneIndex];

					parentTwoIndex = BiasedRand();

					while (parentOneIndex == parentTwoIndex)
					{
						parentTwoIndex = BiasedRand();
					}

					parentTwo = populationOne[parentTwoIndex];
				}
				else
				{
					parentOneIndex = BiasedRand();
					parentOne = populationTwo[parentOneIndex];

					parentTwoIndex = BiasedRand();

					while (parentOneIndex == parentTwoIndex)
					{
						parentTwoIndex = BiasedRand();
					}

					parentTwo = populationTwo[parentTwoIndex];
				}

				Child crossoverChildOne = Crossover(parentOne, parentTwo, numberOfVariables);
				Child crossoverChildTwo = Crossover(parentTwo, parentOne, numberOfVariables);

				if (populationArrayToUse == 1)
				{
					populationOne[i] = crossoverChildOne;
					populationOne[i + (POPULATION / 2)] = crossoverChildTwo;
				}
				else
				{
					populationTwo[i] = crossoverChildOne;
					populationTwo[i + (POPULATION/2)] = crossoverChildTwo;
				}
			}

			cout << "Generation " << generationCount << "\n";

			if (populationArrayToUse == 1)
			{
				Mutation(mutationLevel, populationOne, numberOfExpressions);
				PopulationSort(populationOne);
				output << abs(populationOne[0].GetFitness()) << endl;
				cout << abs(populationOne[0].GetFitness()) << "\n";
				populationArrayToUse = 2;
			}
			else
			{
				Mutation(mutationLevel, populationTwo , numberOfExpressions);
				PopulationSort(populationTwo);
				output << abs(populationTwo[0].GetFitness()) << endl;
				cout << abs(populationTwo[0].GetFitness()) << "\n";
				populationArrayToUse = 1;
			}

			generationCount += 1;
		}

	output.close();

	if (populationArrayToUse == 1)
	{
		populationOne[0].PrintState();
	}
	else
	{
		populationTwo[0].PrintState();
	}

	return 0;
}

